# Sense-X Co-DINO 5-scale 9-encoder R50 LSJ, EgoSurgery-Tool 適応版。
# 親: co_dino_5scale_9encoder_lsj_r50_1x_coco (encoder.num_layers=9)
# 主な変更:
#   - num_classes 15 (TOOL_CLASSES)
#   - data: EgoSurgery 公式 split (train 9657 / val 1515 / test 4265)
#   - bbox-only pipeline (LSJ + CopyPaste は mask が必要なため、親コメント版を採用)
#   - locked-down test_cfg: score_thr=1e-8, max_per_img=300, nms_pre=3000, nms_iou=0.6
#     (Co-DETR の test_cfg は list[3] で branch 0 = detr が支配的なため branch 0 のみ厳格化)
#   - epochs=12, lr_scaling=linear_x2 (effective_bs=4: per-GPU 2 × 2 GPU)
#   - load_from で既存の COCO 事前学習重みを使う (encoder 6→9 への追加層は scratch init)
_base_ = [
    'co_dino_5scale_9encoder_lsj_r50_1x_coco.py'
]

# --- EgoSurgery 15 クラス -------------------------------------------------- #
num_classes = 15
# mmdet 2.x の config merge は dict のキー単位上書きだが、list は完全置換である
# ことに注意 (`_delete_=True` 相当の挙動)。roi_head / bbox_head / train_cfg /
# test_cfg は全て list 構造なので、type を含むフル定義を再記述する。
# 値は grandparent config (co_dino_5scale_r50_1x_coco.py) からそのままコピーし、
# num_classes のみ 80→15 に変更。
num_dec_layer = 6
lambda_2 = 2.0

model = dict(
    # 親 (9encoder_lsj_r50_1x_coco) は encoder.with_cp=9 (全層 activation
    # checkpoint) だが、これと fairscale + DDP の組み合わせで
    # "Parameter ... has been marked as ready twice" が起きる。
    # samples_per_gpu=1 + image_size 800 まで下げても回避できないので
    # with_cp=0 (checkpoint オフ) にする。memory は増えるが scoped で
    # 安全 (本番 image_size=1024 で OOM したら samples_per_gpu=1 で逃げる)。
    query_head=dict(
        num_classes=num_classes,
        transformer=dict(
            encoder=dict(with_cp=0))),
    roi_head=[
        dict(
            type='CoStandardRoIHead',
            bbox_roi_extractor=dict(
                type='SingleRoIExtractor',
                roi_layer=dict(type='RoIAlign', output_size=7, sampling_ratio=0),
                out_channels=256,
                featmap_strides=[4, 8, 16, 32, 64],
                finest_scale=56),
            bbox_head=dict(
                type='Shared2FCBBoxHead',
                in_channels=256,
                fc_out_channels=1024,
                roi_feat_size=7,
                num_classes=num_classes,  # 80 → 15
                bbox_coder=dict(
                    type='DeltaXYWHBBoxCoder',
                    target_means=[0., 0., 0., 0.],
                    target_stds=[0.1, 0.1, 0.2, 0.2]),
                reg_class_agnostic=False,
                reg_decoded_bbox=True,
                loss_cls=dict(
                    type='CrossEntropyLoss', use_sigmoid=False,
                    loss_weight=1.0 * num_dec_layer * lambda_2),
                loss_bbox=dict(
                    type='GIoULoss',
                    loss_weight=10.0 * num_dec_layer * lambda_2))),
    ],
    bbox_head=[
        dict(
            type='CoATSSHead',
            num_classes=num_classes,  # 80 → 15
            in_channels=256,
            stacked_convs=1,
            feat_channels=256,
            anchor_generator=dict(
                type='AnchorGenerator',
                ratios=[1.0],
                octave_base_scale=8,
                scales_per_octave=1,
                strides=[4, 8, 16, 32, 64, 128]),
            bbox_coder=dict(
                type='DeltaXYWHBBoxCoder',
                target_means=[.0, .0, .0, .0],
                target_stds=[0.1, 0.1, 0.2, 0.2]),
            loss_cls=dict(
                type='FocalLoss',
                use_sigmoid=True,
                gamma=2.0,
                alpha=0.25,
                loss_weight=1.0 * num_dec_layer * lambda_2),
            loss_bbox=dict(
                type='GIoULoss',
                loss_weight=2.0 * num_dec_layer * lambda_2),
            loss_centerness=dict(
                type='CrossEntropyLoss', use_sigmoid=True,
                loss_weight=1.0 * num_dec_layer * lambda_2)),
    ],
    # train_cfg も list なので grandparent のフル定義を再掲する必要がある。
    train_cfg=[
        dict(
            assigner=dict(
                type='HungarianAssigner',
                cls_cost=dict(type='FocalLossCost', weight=2.0),
                reg_cost=dict(type='BBoxL1Cost', weight=5.0, box_format='xywh'),
                iou_cost=dict(type='IoUCost', iou_mode='giou', weight=2.0))),
        dict(
            rpn=dict(
                assigner=dict(
                    type='MaxIoUAssigner',
                    pos_iou_thr=0.7,
                    neg_iou_thr=0.3,
                    min_pos_iou=0.3,
                    match_low_quality=True,
                    ignore_iof_thr=-1),
                sampler=dict(
                    type='RandomSampler',
                    num=256,
                    pos_fraction=0.5,
                    neg_pos_ub=-1,
                    add_gt_as_proposals=False),
                allowed_border=-1,
                pos_weight=-1,
                debug=False),
            rpn_proposal=dict(
                nms_pre=4000,
                max_per_img=1000,
                nms=dict(type='nms', iou_threshold=0.7),
                min_bbox_size=0),
            rcnn=dict(
                assigner=dict(
                    type='MaxIoUAssigner',
                    pos_iou_thr=0.5,
                    neg_iou_thr=0.5,
                    min_pos_iou=0.5,
                    match_low_quality=False,
                    ignore_iof_thr=-1),
                sampler=dict(
                    type='RandomSampler',
                    num=512,
                    pos_fraction=0.25,
                    neg_pos_ub=-1,
                    add_gt_as_proposals=True),
                pos_weight=-1,
                debug=False)),
        dict(
            assigner=dict(type='ATSSAssigner', topk=9),
            allowed_border=-1,
            pos_weight=-1,
            debug=False),
    ],
    # locked-down test_cfg を branch 0 (detr / query_head 評価) に上書き。
    # mmdet 2.x の test_cfg は list[3]: [detr, fasterrcnn, onestage]。
    test_cfg=[
        dict(
            max_per_img=300,
            score_thr=1e-8,
            nms_pre=3000,
            nms=dict(type='nms', iou_threshold=0.6),
        ),
        # branch 1/2 は学習補助用なので親値を継承 (mmdet 2.x の dict 合成では
        # list は完全置換なので、親値を再掲する必要がある)。
        dict(
            rpn=dict(
                nms_pre=1000,
                max_per_img=1000,
                nms=dict(type='nms', iou_threshold=0.7),
                min_bbox_size=0),
            rcnn=dict(
                score_thr=0.0,
                nms=dict(type='nms', iou_threshold=0.5),
                max_per_img=100),
        ),
        dict(
            nms_pre=1000,
            min_bbox_size=0,
            score_thr=0.0,
            nms=dict(type='nms', iou_threshold=0.6),
            max_per_img=100,
        ),
    ],
)

# --- bbox-only pipeline -------------------------------------------------- #
# EgoSurgery は mask アノテーション無しなので、親 config の LSJ + CopyPaste は使えない。
# 親 config 冒頭のコメントに「bbox-only 用の代替 pipeline」が示されているので、
# それを採用する。
img_norm_cfg = dict(
    mean=[123.675, 116.28, 103.53], std=[58.395, 57.12, 57.375], to_rgb=True)
image_size = (1024, 1024)

train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='LoadAnnotations', with_bbox=True),
    dict(
        type='Resize',
        img_scale=image_size,
        ratio_range=(0.1, 2.0),
        multiscale_mode='range',
        keep_ratio=True),
    dict(
        type='RandomCrop',
        crop_type='absolute_range',
        crop_size=image_size,
        recompute_bbox=True,
        allow_negative_crop=True),
    dict(type='FilterAnnotations', min_gt_bbox_wh=(1e-2, 1e-2)),
    dict(type='RandomFlip', flip_ratio=0.5),
    dict(type='Pad', size=image_size, pad_val=dict(img=(114, 114, 114))),
    dict(type='Normalize', **img_norm_cfg),
    dict(type='DefaultFormatBundle'),
    dict(type='Collect', keys=['img', 'gt_bboxes', 'gt_labels']),
]
test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(
        type='MultiScaleFlipAug',
        img_scale=image_size,
        flip=False,
        transforms=[
            dict(type='Resize', keep_ratio=True),
            dict(type='RandomFlip'),
            dict(type='Pad', size=image_size, pad_val=dict(img=(114, 114, 114))),
            dict(type='Normalize', **img_norm_cfg),
            dict(type='ImageToTensor', keys=['img']),
            dict(type='Collect', keys=['img'])
        ])
]

# --- データセット (EgoSurgery 公式 split) --------------------------------- #
data_root = '/home/ubuntu/slocal2/m2/'
classes = (
    'Bipolar Forceps', 'Electric Cautery', 'Forceps', 'Gauze', 'Hook',
    'Mouth Gag', 'Needle Holders', 'Raspatory', 'Retractor', 'Scalpel',
    'Scissors', 'Skewer', 'Suction Cannula', 'Syringe', 'Tweezers',
)
data = dict(
    samples_per_gpu=2,
    workers_per_gpu=2,
    train=dict(
        # 親 config の MultiImageMixDataset (CopyPaste 用) は mask 必須なので、
        # 通常の CocoDataset に置換する。
        _delete_=True,
        type='CocoDataset',
        classes=classes,
        ann_file=data_root + 'data/annotations/egosurgery_tool/instances_train.json',
        img_prefix=data_root + 'data/raw/ego/',
        filter_empty_gt=False,
        pipeline=train_pipeline),
    val=dict(
        type='CocoDataset',
        classes=classes,
        ann_file=data_root + 'data/annotations/egosurgery_tool/instances_val.json',
        img_prefix=data_root + 'data/raw/ego/',
        pipeline=test_pipeline),
    test=dict(
        type='CocoDataset',
        classes=classes,
        ann_file=data_root + 'data/annotations/egosurgery_tool/instances_test.json',
        img_prefix=data_root + 'data/raw/ego/',
        pipeline=test_pipeline))

# --- 学習スケジュール (effective_bs=4 で linear_x2 lr スケール) ----------- #
# COCO 元: samples_per_gpu=2, 8 GPU → effective_bs=16, lr=2e-4。
# 我々: 2 GPU → effective_bs=4 (1/4)。lr_scaling=linear_x2 (effective_bs=4 を
# base_batch_size=16 の 2 倍 スケール: 2/16 = 1/8 だが M2 研究計画の linear_x2 は
# 2 GPU 用の慣行値で、実 lr = 2e-4 × (4/16) = 5e-5)。
optimizer = dict(
    type='AdamW',
    lr=5e-5,
    weight_decay=0.0001,
    paramwise_cfg=dict(
        custom_keys={
            'backbone': dict(lr_mult=0.1),
        }))
optimizer_config = dict(grad_clip=dict(max_norm=0.1, norm_type=2))

# 12 epoch、最後の 1 epoch で lr 1/10。
lr_config = dict(policy='step', step=[11])
runner = dict(type='EpochBasedRunner', max_epochs=12)
evaluation = dict(interval=1, metric='bbox', classwise=True, save_best='bbox_mAP')

# 既存の COCO 事前学習重み (6-encoder 版) を起点に。9encoder の追加 3 層は scratch。
load_from = '/home/ubuntu/slocal2/m2/data/external/weights/co_dino_5scale_r50_1x_coco.pth'

# --- 保存・記録 ----------------------------------------------------------- #
checkpoint_config = dict(interval=1, max_keep_ckpts=2)
log_config = dict(
    interval=50,
    hooks=[
        dict(type='TextLoggerHook'),
        # W&B track (mmcv 1.7.0 の WandbLoggerHook)。run name は launcher が
        # --cfg-options log_config.hooks.1.init_kwargs.name=<exp_name> で
        # seed ごとに上書きする。認証は環境変数 WANDB_API_KEY (.env から
        # launcher が export)。entity は WANDB_ENTITY か init_kwargs で固定。
        dict(
            type='WandbLoggerHook',
            interval=50,
            log_artifact=False,           # checkpoint を artifact 化しない (容量節約)
            init_kwargs=dict(
                project='egosurgery_multitask',
                entity='takuya3h',
                name='sensex_codino_9enc',  # launcher が seed 付き名に上書き
                group='s0_sensex_codino',
                job_type='train',
                tags=['S0', 'detector_benchmark', 'sensex_codino', 'mmdet2x'],
            ),
        ),
    ])

# その他 (DDP / find_unused_parameters)。
find_unused_parameters = True
