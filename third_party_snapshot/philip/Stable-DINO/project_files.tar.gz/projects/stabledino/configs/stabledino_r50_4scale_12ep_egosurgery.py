# Stable-DINO R50 4scale 12ep, EgoSurgery-Tool 適応版 (detrex lazy config)。
# 親: stabledino_r50_4scale_12ep。主な変更:
#   - model.num_classes 80 -> 15
#   - dataloader を EgoSurgery 登録データセット (egosurgery_{train,val,test}) へ
#   - bbox-only: EgoSurgery の segmentation はダミーなので mask を使わない
#     (detrex DINO の mapper は元々 bbox 検出用で mask を読まないため追加対応不要だが
#      念のため mask 無効を明示)
#   - 学習スケジュール: effective_bs=4 (2GPU x per-gpu 2), 12ep = 28980 iter,
#     lr step=26565 (11ep相当), eval/checkpoint=2415 iter (1ep) ごと
#   - locked-down test: 他検出器と揃える (score_thr=1e-8 相当 = topk 全取り,
#     max_per_img=300)。DINO は topk 方式で NMS-free。
#   - init_checkpoint: detrex DINO R50 COCO 12ep 重み (backbone+transformer を
#     初期化し、15クラスの class_embed のみ COCO80->15 で形状不一致のため再初期化)。
#     これにより他検出器 (COCO fine-tune) と初期化条件を揃える。
#   - wandb track 有効化 (CLAUDE.md: 全実験を W&B 追跡)。run name は launcher が上書き。
from detrex.config import get_config
from .models.stabledino_r50 import model

dataloader = get_config("common/data/coco_detr.py").dataloader
optimizer = get_config("common/optim.py").AdamW
lr_multiplier = get_config("common/coco_schedule.py").lr_multiplier_12ep
train = get_config("common/train.py").train

# --- EgoSurgery 15 クラス ------------------------------------------------- #
model.num_classes = 15

# --- データセット (EgoSurgery 公式 split。登録は train_net ラッパが行う) --- #
dataloader.train.dataset.names = "egosurgery_train"
dataloader.test.dataset.names = "egosurgery_val"
dataloader.train.total_batch_size = 4  # 2 GPU x per-gpu 2 = effective_bs 4
dataloader.train.num_workers = 8

# --- 学習スケジュール (effective_bs=4, 12 epoch) -------------------------- #
# train 9657 枚 / bs 4 = 2415 iter/epoch。12ep = 28980 iter。
_iters_per_epoch = 2415
train.max_iter = _iters_per_epoch * 12          # 28980
train.eval_period = _iters_per_epoch            # 1 epoch ごとに val
train.checkpointer.period = _iters_per_epoch
train.log_period = 50

# lr step を 11 epoch 相当に置き直す。元の COCO 設定 (values=[1.0,0.1],
# milestones=[82500,90000]) と同じ「milestones の最後 = max_iter」構造を維持する。
# num_updates は設定しない (設定すると fvcore が milestones=1要素 を要求して壊れる)。
lr_multiplier.scheduler.milestones = [_iters_per_epoch * 11, train.max_iter]
# warmup は元の比率 (約 0.00028 * 90000 ≈ 25 iter) を維持。
lr_multiplier.warmup_length = 25 / train.max_iter

# --- optimizer (他検出器と揃える: AdamW lr=1e-4, backbone 0.1x, wd 1e-4) -- #
optimizer.lr = 1e-4
optimizer.betas = (0.9, 0.999)
optimizer.weight_decay = 1e-4
optimizer.params.lr_factor_func = lambda module_name: 0.1 if "backbone" in module_name else 1

# --- 勾配クリップ (DINO 既定) -------------------------------------------- #
train.clip_grad.enabled = True
train.clip_grad.params.max_norm = 0.1
train.clip_grad.params.norm_type = 2

# --- locked-down test (他検出器と評価条件を揃える) ----------------------- #
# DINO は topk 方式 (NMS-free)。max_per_img=300 を select_box_nums で表現。
# detrex の DINO は model.select_box_nums_for_evaluation で制御。
model.select_box_nums_for_evaluation = 300

# --- 初期化: detrex DINO R50 COCO 12ep 重み ------------------------------ #
# backbone + transformer をロード、class_embed (80->15) は形状不一致で自動 skip
# されるため 15 クラス head は再初期化 (= 他検出器の COCO fine-tune と同条件)。
train.init_checkpoint = "/home/ubuntu/slocal2/m2/data/external/weights/dino_r50_4scale_12ep_detrex.pth"

train.output_dir = "/tmp/stabledino_work"  # launcher が seed 別に上書き
train.device = "cuda"
model.device = train.device

# --- W&B track (CLAUDE.md: 全実験を必ず追跡) ----------------------------- #
train.wandb.enabled = True
train.wandb.params.project = "egosurgery_multitask"
train.wandb.params.name = "stabledino_r50_4scale_12ep"  # launcher が seed 別に上書き
train.wandb.params.dir = "/tmp/stabledino_work"

dataloader.evaluator.output_dir = train.output_dir
