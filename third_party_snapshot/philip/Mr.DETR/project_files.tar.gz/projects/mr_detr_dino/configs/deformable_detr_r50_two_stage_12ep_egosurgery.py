# Mr. DETR (DINO route) R50 two-stage 12ep, EgoSurgery-Tool 適応版 (detrex lazy config)。
# 親: deformable_detr_r50_two_stage_12ep_plusplus (Deformable-DETR two-stage ベース,
# Mr.DETR の instructive multi-route training: 主 route=one-to-one, 補助 route=one-to-many)。
# Stable-DINO/Align-DETR の egosurgery 適応と同方針で S0 ベンチ条件に揃える:
#   - num_classes 80 -> 15 (Mr.DETR は criterion〜criterion5 の5つが
#     num_classes="${..num_classes}" で親参照のため model.num_classes=15 のみで全伝播)
#   - dataloader を EgoSurgery 登録データセット (egosurgery_{train,val}) へ
#   - effective_bs=4 (2GPU x per-gpu 2), 12ep=28980 iter, lr step=11ep, eval/ckpt=1ep
#   - locked-down test: topk NMS-free, max_per_img=300 (他検出器と一致)
#   - init_checkpoint: Mr.DETR R50 COCO 12ep 重み (HF allencbzhang/Mr.DETR。準備でDL。
#     class_embed は 80->15 で形状不一致 skip = 他検出器の COCO fine-tune と同条件)。未取得時 ImageNet。
#   - wandb track 有効。補助 route は推論時に除去されるため推論コストは one-to-one と同一。
from .deformable_detr_r50_two_stage_12ep_plusplus import (
    train, dataloader, optimizer, lr_multiplier, model,
)

# --- EgoSurgery 15 クラス --------------------------------------------- #
# 注意: Mr.DETR の model 定義は criterion の num_classes を直値 80 でハードコード
# (configs/models/deformable_detr_r50.py: criterion=L(DNCriterion)(num_classes=80))。
# detrex の参照式 "${..num_classes}" ではないため、model.num_classes だけでは
# criterion に伝播しない。criterion.num_classes も明示上書きする (15クラス head 不整合防止)。
model.num_classes = 15
model.criterion.num_classes = 15

# --- データセット (登録は train_net ラッパが行う) ------------------------ #
dataloader.train.dataset.names = "egosurgery_train"
dataloader.test.dataset.names = "egosurgery_val"
dataloader.train.total_batch_size = 4  # 2 GPU x per-gpu 2
dataloader.train.num_workers = 8

# --- 学習スケジュール (effective_bs=4, 12 epoch) ------------------------- #
_iters_per_epoch = 2415                           # train 9657 / bs 4
train.max_iter = _iters_per_epoch * 12            # 28980
train.eval_period = _iters_per_epoch
train.checkpointer.period = _iters_per_epoch
train.log_period = 50
lr_multiplier.scheduler.milestones = [_iters_per_epoch * 11, train.max_iter]
lr_multiplier.warmup_length = 25 / train.max_iter

# --- optimizer (他検出器と揃える) --------------------------------------- #
optimizer.lr = 1e-4
optimizer.betas = (0.9, 0.999)
optimizer.weight_decay = 1e-4
optimizer.params.lr_factor_func = lambda module_name: 0.1 if "backbone" in module_name else 1

# --- 勾配クリップ ------------------------------------------------------- #
train.clip_grad.enabled = True
train.clip_grad.params.max_norm = 0.1
train.clip_grad.params.norm_type = 2

# --- locked-down test --------------------------------------------------- #
model.select_box_nums_for_evaluation = 300

# --- 初期化: Mr.DETR R50 COCO 12ep 重み (準備でDL。未取得時 ImageNet) ----- #
train.init_checkpoint = "/home/ubuntu/slocal2/m2/data/external/weights/mrdetr_dino_r50_12ep_coco.pth"

train.output_dir = "/tmp/mrdetr_dino_work"
train.device = "cuda"
model.device = train.device

# --- W&B track ---------------------------------------------------------- #
train.wandb.enabled = True
train.wandb.params.project = "egosurgery_multitask"
train.wandb.params.name = "mrdetr_dino_r50_12ep"
train.wandb.params.dir = "/tmp/mrdetr_dino_work"

dataloader.evaluator.output_dir = train.output_dir
