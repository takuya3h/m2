# Mr. DETR (Align route) R50 two-stage 12ep, EgoSurgery-Tool 適応版 (detrex lazy config)。
# 親: deformable_detr_r50_two_stage_12ep_plusplus (Mr.DETR の Align variant =
# IoU-aware/Align loss を補助 route に組み込んだ版)。DINO route 版と同じ S0 ベンチ整合。
#   - num_classes 80 -> 15 (criterion×5 は num_classes="${..num_classes}" 参照で自動伝播)
#   - dataloader=EgoSurgery, effective_bs=4, 12ep=28980 iter, lr step=11ep, eval/ckpt=1ep
#   - locked-down test: topk NMS-free, max_per_img=300
#   - init_checkpoint: Mr.DETR Align R50 COCO 12ep 重み (HF。準備でDL。未取得時 ImageNet)
#   - wandb track 有効。
from .deformable_detr_r50_two_stage_12ep_plusplus import (
    train, dataloader, optimizer, lr_multiplier, model,
)

# --- EgoSurgery 15 クラス --------------------------------------------- #
# 注意: Mr.DETR の criterion は num_classes を直値 80 でハードコード (参照式でない)。
# model.num_classes だけでは伝播しないため criterion.num_classes も明示上書きする。
model.num_classes = 15
model.criterion.num_classes = 15

# --- データセット (登録は train_net ラッパが行う) ------------------------ #
dataloader.train.dataset.names = "egosurgery_train"
dataloader.test.dataset.names = "egosurgery_val"
dataloader.train.total_batch_size = 4
dataloader.train.num_workers = 8

# --- 学習スケジュール (effective_bs=4, 12 epoch) ------------------------- #
_iters_per_epoch = 2415
train.max_iter = _iters_per_epoch * 12            # 28980
train.eval_period = _iters_per_epoch
train.checkpointer.period = _iters_per_epoch
train.log_period = 50
lr_multiplier.scheduler.milestones = [_iters_per_epoch * 11, train.max_iter]
lr_multiplier.warmup_length = 25 / train.max_iter

# --- optimizer (他検出器と揃える) --------------------------------------- #
optimizer.lr = 1e-4
optimizer.betas = (0.9, 0.999)
optimizer.weight_decay = 1e-4
optimizer.params.lr_factor_func = lambda module_name: 0.1 if "backbone" in module_name else 1

# --- 勾配クリップ ------------------------------------------------------- #
train.clip_grad.enabled = True
train.clip_grad.params.max_norm = 0.1
train.clip_grad.params.norm_type = 2

# --- locked-down test --------------------------------------------------- #
model.select_box_nums_for_evaluation = 300

# --- 初期化: Mr.DETR Align R50 COCO 12ep 重み (準備でDL。未取得時 ImageNet) - #
train.init_checkpoint = "/home/ubuntu/slocal2/m2/data/external/weights/mrdetr_align_r50_12ep_coco.pth"

train.output_dir = "/tmp/mrdetr_align_work"
train.device = "cuda"
model.device = train.device

# --- W&B track ---------------------------------------------------------- #
train.wandb.enabled = True
train.wandb.params.project = "egosurgery_multitask"
train.wandb.params.name = "mrdetr_align_r50_12ep"
train.wandb.params.dir = "/tmp/mrdetr_align_work"

dataloader.evaluator.output_dir = train.output_dir
