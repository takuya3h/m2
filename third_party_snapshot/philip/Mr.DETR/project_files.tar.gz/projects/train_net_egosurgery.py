#!/usr/bin/env python3
"""train_net_egosurgery.py — Mr.DETR 同梱 train_net を EgoSurgery 用にラップ。

Mr.DETR は detrex/detectron2 を自己同梱し、projects/train_net.py が
`sys.path.append(projects/..)` で projects.mr_detr_* の modeling を解決する。
共有の detrex ラッパは Mr.DETR 独自 modeling を見ないため使えない → 専用ラッパ。

方針は detrex 版 train_net_egosurgery と同一:
  - EgoSurgery 15 クラスを register_coco_instances で登録 (正クラス名)
  - spawn 子プロセス対策: 登録関数と launch 対象をトップレベルに置き、import 時にも登録
使い方 (Mr.DETR repo ルートを cwd / PYTHONPATH に):
  python projects/train_net_egosurgery.py \
      --config-file projects/mr_detr_dino/configs/..._egosurgery.py --num-gpus 2 \
      train.seed=42 train.output_dir=/tmp/work
"""
import os
import sys
from pathlib import Path

# Mr.DETR ルート (= projects/ の親) を import パスへ。projects.mr_detr_* 解決用。
_MRDETR_ROOT = str(Path(__file__).resolve().parents[1])
if _MRDETR_ROOT not in sys.path:
    sys.path.insert(0, _MRDETR_ROOT)
# projects/ 自身も (train_net 本体が同階層を参照するため)
sys.path.insert(0, str(Path(__file__).resolve().parent))

from detectron2.data.datasets import register_coco_instances  # noqa: E402

EGOSURGERY_CLASSES = [
    "Bipolar Forceps", "Electric Cautery", "Forceps", "Gauze", "Hook",
    "Mouth Gag", "Needle Holders", "Raspatory", "Retractor", "Scalpel",
    "Scissors", "Skewer", "Suction Cannula", "Syringe", "Tweezers",
]
_ANN = "/home/ubuntu/slocal2/m2/data/annotations/egosurgery_tool"
_IMG = "/home/ubuntu/slocal2/m2/data/raw/ego"


def register_egosurgery():
    """EgoSurgery train/val/test を DatasetCatalog に登録 (未登録時のみ)。"""
    from detectron2.data import DatasetCatalog, MetadataCatalog

    for split in ("train", "val", "test"):
        name = f"egosurgery_{split}"
        if name in DatasetCatalog.list():
            continue
        register_coco_instances(name, {}, f"{_ANN}/instances_{split}.json", _IMG)
        MetadataCatalog.get(name).thing_classes = list(EGOSURGERY_CLASSES)


# spawn 子プロセスはこのモジュールを再 import するため、import 時にも登録。
register_egosurgery()

import train_net as mrdetr_train_net  # noqa: E402


def main_with_register(args):
    """登録を保証してから Mr.DETR 本体 main を呼ぶ (トップレベル = pickle 可能)。"""
    register_egosurgery()
    return mrdetr_train_net.main(args)


if __name__ == "__main__":
    from detectron2.engine import default_argument_parser, launch  # noqa: E402

    args = default_argument_parser().parse_args()
    launch(
        main_with_register,
        args.num_gpus,
        num_machines=args.num_machines,
        machine_rank=args.machine_rank,
        dist_url=args.dist_url,
        args=(args,),
    )
