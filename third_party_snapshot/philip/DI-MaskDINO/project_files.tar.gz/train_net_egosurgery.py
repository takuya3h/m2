#!/usr/bin/env python3
"""DI-MaskDINO を EgoSurgery で学習するラッパ (detectron2 launch, spawn 対応)。

detectron2 の launch() は --num-gpus>=2 で spawn により子プロセスを生成し、
対象関数を pickle する。EgoSurgery データ登録をモジュールトップレベルに置き、
子プロセスの再 import 時にも確実に登録する (Stable-DINO の同名ラッパと同パターン)。

Usage:
  python train_net_egosurgery.py --config-file configs/dimaskdino_r50_egosurgery.yaml \
      --num-gpus 2 --dist-url tcp://127.0.0.1:29600 \
      SEED 42 OUTPUT_DIR /tmp/dimaskdino_work_seed42
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from detectron2.data.datasets import register_coco_instances
from detectron2.data import DatasetCatalog, MetadataCatalog

_PROJ = "/home/ubuntu/slocal2/m2"
_ANN = f"{_PROJ}/data/annotations/egosurgery_tool"
_IMG = f"{_PROJ}/data/raw/ego"
_CLASSES = [
    "Bipolar Forceps", "Electric Cautery", "Forceps", "Gauze", "Hook",
    "Mouth Gag", "Needle Holders", "Raspatory", "Retractor", "Scalpel",
    "Scissors", "Skewer", "Suction Cannula", "Syringe", "Tweezers",
]


def _register_egosurgery():
    for split in ("train", "val", "test"):
        name = f"egosurgery_{split}"
        if name in DatasetCatalog.list():
            continue
        register_coco_instances(name, {}, f"{_ANN}/instances_{split}.json", _IMG)
        MetadataCatalog.get(name).thing_classes = list(_CLASSES)


# トップレベル登録 (spawn 子プロセスの再 import 時にも実行される)
_register_egosurgery()

import train_net as _dim_train_net  # noqa: E402


def main_with_register(args):
    _register_egosurgery()  # 冪等 (念のため main 内でも)
    return _dim_train_net.main(args)


if __name__ == "__main__":
    from detectron2.engine import default_argument_parser, launch

    args = default_argument_parser().parse_args()
    launch(
        main_with_register,
        args.num_gpus,
        num_machines=args.num_machines,
        machine_rank=args.machine_rank,
        dist_url=args.dist_url,
        args=(args,),
    )
