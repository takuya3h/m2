"""val mAP の停滞で学習率を一度だけ下げ、再び停滞したら打ち切る規則。

契約 T-2026-09-19-stage1-detector-towers-r2 / prereg §2。一周目（12 epoch 固定・
`MultiStepLR([10])`）は検出ヘッドが乱数初期化の塔に足りず、**同じ epoch 数が同じ学習量を
意味しない**ことが実測で分かった。長さの決め方だけを収束基準へ替える。

**塔を見る分岐がここに無い。** 規則は `observe` の 1 本だけで、D*-COCO と D*-ImageNet は
同じ経路を通る。低下と打ち切りの epoch が塔ごとに違うのは入力（val mAP の並び）の違いで
あって、規則の違いではない。

規則:
    - val mAP が `patience` epoch 続けて最良を更新しなければ学習率を `factor` 倍にする
    - 低下は **一度だけ**。低下の後、再び `patience` epoch 続けて更新しなければ打ち切る
    - 「改善」は**それまでの最良の更新**を指す。低下しても最良はさかのぼらない
    - 上限 epoch は呼び出し側（学習ループの範囲）が持つ。ここでは扱わない
"""
from __future__ import annotations

from dataclasses import dataclass, field

CONTINUE = "continue"
DECAY = "decay"
STOP = "stop"


@dataclass
class PlateauSchedule:
    """val mAP の並びだけから、低下と打ち切りの時期を決める。

    装置も分散処理も見ない。**同じ並びを与えれば同じ判断を返す。**
    そのため試験で低下・打ち切りの時期を直に確かめられる。

    Attributes:
        patience: 何 epoch 続けて最良を更新しなければ動くか。
        factor: 学習率に掛ける倍率。
        best: それまでの最良の val mAP。未観測なら None。
        best_epoch: 最良を観測した epoch（0 起点）。
        bad_epochs: 最良を更新できずに続いた epoch 数。
        decayed_epoch: 学習率を下げた epoch。下げていなければ None。
        stopped_epoch: 打ち切った epoch。打ち切っていなければ None。
        history: 観測した val mAP の並び。
    """

    patience: int = 4
    factor: float = 0.1
    best: float | None = None
    best_epoch: int | None = None
    bad_epochs: int = 0
    decayed_epoch: int | None = None
    stopped_epoch: int | None = None
    history: list[float] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.patience < 1:
            raise ValueError(f"patience は 1 以上である必要がある: {self.patience}")

    @property
    def decayed(self) -> bool:
        return self.decayed_epoch is not None

    def observe(self, epoch: int, ap: float) -> str:
        """1 epoch 分の val mAP を受け取り、次に何をするかを返す。

        Returns:
            CONTINUE / DECAY / STOP のいずれか。DECAY は呼び出し側が学習率へ
            `factor` を掛けることを、STOP は学習ループを抜けることを意味する。
        """
        self.history.append(ap)
        if self.best is None or ap > self.best:
            self.best = ap
            self.best_epoch = epoch
            self.bad_epochs = 0
            return CONTINUE

        self.bad_epochs += 1
        if self.bad_epochs < self.patience:
            return CONTINUE

        self.bad_epochs = 0
        if not self.decayed:
            self.decayed_epoch = epoch
            return DECAY
        self.stopped_epoch = epoch
        return STOP

    def summary(self) -> dict:
        """報告に使う事実だけを返す。**測っていない値は None のままにする。**"""
        return {
            "patience": self.patience,
            "factor": self.factor,
            "best_ap": self.best,
            "best_epoch": self.best_epoch,
            "decayed_epoch": self.decayed_epoch,
            "stopped_epoch": self.stopped_epoch,
            "observed_epochs": len(self.history),
            "val_ap_per_epoch": self.history,
        }
