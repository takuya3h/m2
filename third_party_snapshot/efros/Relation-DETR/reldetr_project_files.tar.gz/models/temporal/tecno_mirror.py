"""TeCNO 工程ヘッドの最小ミラー（B1 素朴MTL の工程枝）。

本体 ``src/egosurgery/models/heads/tecno_head.py`` の **完全な動作ミラー**（純 torch・
egosurgery 非依存）。.venv-relation-detr は egosurgery パッケージを持たないため、検出枝
（Relation-DETR）と同一プロセスで工程枝を回すために自己完結で複製する（c5_linear_neck の
ミラーと同じ方針）。挙動・既定値（num_stages=2/num_layers=8/num_f_maps=64/in_dim=2048/
num_classes=9, causal=左 pad のみ）は本体と一致させる。

入出力:
    forward(x): x=(B, in_dim, T) → 各ステージのロジット列 [(B, num_classes, T), ...]。
    smoothing_loss(logits): MS-TCN の T-MSE 平滑化損失（本体 train_s4_tecno.py と同式）。
"""
from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn


class CausalDilatedResidualLayer(nn.Module):
    """因果的 dilated 残差層（kernel=3）。出力時刻 t は入力 ≤ t のみに依存する。"""

    def __init__(self, dilation: int, n_channels: int, dropout: float = 0.5) -> None:
        super().__init__()
        self.dilation = dilation
        self.conv_dilated = nn.Conv1d(n_channels, n_channels, kernel_size=3, dilation=dilation)
        self.conv_1x1 = nn.Conv1d(n_channels, n_channels, kernel_size=1)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = F.pad(x, (2 * self.dilation, 0))  # 左のみ pad → causal
        out = F.relu(self.conv_dilated(out))
        out = self.conv_1x1(out)
        out = self.dropout(out)
        return x + out


class SingleStageTCN(nn.Module):
    """1 ステージ分の因果 TCN。dilation を 2^l で指数増加させる。"""

    def __init__(self, num_layers: int, n_channels: int, in_dim: int, num_classes: int,
                 dropout: float = 0.5) -> None:
        super().__init__()
        self.conv_in = nn.Conv1d(in_dim, n_channels, kernel_size=1)
        self.layers = nn.ModuleList(
            [CausalDilatedResidualLayer(2 ** i, n_channels, dropout) for i in range(num_layers)]
        )
        self.conv_out = nn.Conv1d(n_channels, num_classes, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.conv_in(x)
        for layer in self.layers:
            out = layer(out)
        return self.conv_out(out)


class TeCNO(nn.Module):
    """Causal Multi-Stage TCN（TeCNO）。online 工程認識ヘッド（本体ミラー）。"""

    def __init__(self, num_stages: int = 2, num_layers: int = 8, num_f_maps: int = 64,
                 in_dim: int = 2048, num_classes: int = 9, dropout: float = 0.5) -> None:
        super().__init__()
        self.num_stages = num_stages
        self.num_classes = num_classes
        self.stage1 = SingleStageTCN(num_layers, num_f_maps, in_dim, num_classes, dropout)
        self.refine_stages = nn.ModuleList(
            [SingleStageTCN(num_layers, num_f_maps, num_classes, num_classes, dropout)
             for _ in range(num_stages - 1)]
        )

    def forward(self, x: torch.Tensor) -> list[torch.Tensor]:
        out = self.stage1(x)
        outputs = [out]
        for stage in self.refine_stages:
            out = stage(F.softmax(out, dim=1))
            outputs.append(out)
        return outputs


def smoothing_loss(logits: torch.Tensor) -> torch.Tensor:
    """MS-TCN の T-MSE 平滑化損失（本体 train_s4_tecno.py::smoothing_loss と同式）。"""
    ls = F.log_softmax(logits, dim=1)
    mse = F.mse_loss(ls[:, :, 1:], ls[:, :, :-1], reduction="none")
    return torch.clamp(mse, max=16.0).mean()
