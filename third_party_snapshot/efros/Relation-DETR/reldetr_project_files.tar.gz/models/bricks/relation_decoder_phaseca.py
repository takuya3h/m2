"""T1b-CA: Phase→Det cross-attention 注入用 decoder 層（§4.6 primary・①予測相互作用 L3）。

§12.7 C6 / §12.22 C2 が primary と定める「decoder の cross-attention に c_phase を追加 KV として
注入」を Relation-DETR の deformable decoder へ自前実装する。既存 decoder 層に **「query→c_phase
token」標準 cross-attention 副層を 1 本だけ追加**し、その出力射影（phase_attn.out_proj）を
**zero-init** する。よって warm-start 直後は寄与 0＝base 層と厳密一致（=S0-frozen）で、fine-tune で
初めて phase 変調を学習する。これは T1b(FiLM) の「最終層 zero-init→恒等」と同一原理（§4.6 下限 FiLM
に対する primary CA の ablation を、同一プロトコルで清潔に比較できる）。

c_phase token は detector(`RelationDETRPhaseCrossAttn`)の ``set_phase_context`` が各層の ``_c_phase``
に配る。``_c_phase is None``（eval/対照フォールバック）なら phase 副層を skip＝恒等。
.venv-relation-detr は egosurgery を持たないため C5LinearNeck / phasefilm と同様に自己完結で実装する。
"""
from models.bricks.relation_transformer import RelationTransformerDecoderLayer
from torch import nn


class RelationTransformerDecoderLayerPhaseCA(RelationTransformerDecoderLayer):
    """RelationTransformerDecoderLayer に Phase→Det cross-attention（zero-init=恒等）を追加した派生層。"""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        # query → c_phase token への標準 cross-attention（1 トークンに注意）。
        self.phase_norm = nn.LayerNorm(self.embed_dim)
        self.phase_attn = nn.MultiheadAttention(self.embed_dim, self.num_heads, batch_first=True)
        # out_proj を zero-init → 初期は注入寄与 0（恒等）。勾配は out_proj へ流れ学習が始まる
        # （FiLM の mlp[-1] zero-init と同一の仕組み）。
        nn.init.zeros_(self.phase_attn.out_proj.weight)
        nn.init.zeros_(self.phase_attn.out_proj.bias)
        self._c_phase = None  # (B,1,embed) を detector.set_phase_context が配る

    def forward(
        self,
        query,
        query_pos,
        reference_points,
        value,
        spatial_shapes,
        level_start_index,
        self_attn_mask=None,
        key_padding_mask=None,
    ):
        # self attention（base と同一）
        query_with_pos = key_with_pos = self.with_pos_embed(query, query_pos)
        query2 = self.self_attn(
            query=query_with_pos, key=key_with_pos, value=query,
            attn_mask=self_attn_mask, need_weights=False,
        )[0]
        query = self.norm2(query + self.dropout2(query2))

        # deformable cross attention（base と同一）
        query2 = self.cross_attn(
            query=self.with_pos_embed(query, query_pos),
            reference_points=reference_points, value=value,
            spatial_shapes=spatial_shapes, level_start_index=level_start_index,
            key_padding_mask=key_padding_mask,
        )
        query = self.norm1(query + self.dropout1(query2))

        # ★ Phase→Det cross-attention 注入（zero-init out_proj → 初期恒等。norm 無しの残差加算で
        #   _c_phase=None / 初期重み 0 のとき query を厳密に保つ＝base 層と一致）。
        if self._c_phase is not None:
            tok = self._c_phase
            if tok.shape[0] != query.shape[0]:  # hybrid/denoising 等でバッチが変わる場合に整合
                if query.shape[0] % tok.shape[0] == 0:
                    tok = tok.repeat(query.shape[0] // tok.shape[0], 1, 1)
                else:
                    tok = tok[:1].expand(query.shape[0], -1, -1)
            delta = self.phase_attn(
                query=self.phase_norm(query), key=tok, value=tok, need_weights=False,
            )[0]
            query = query + delta

        # ffn（base と同一）
        query = self.forward_ffn(query)
        return query
