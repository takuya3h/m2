"""B1 素朴MTL 検出器（②特徴レベル結合・最初の結合手法）。

比較の三角形 ②系統で、共有 C5 線形 neck に**検出損失と工程損失の勾配を同時に流す**素朴MTL。
凍結 backbone のため共有 trainable は ``c5_neck`` のみ。検出枝は親 ``RelationDETRC5Neck`` の
forward をそのまま使い（``c5_neck.forward`` = spatial）、工程枝は ``forward_phase`` で
``c5_neck.forward_vector``（同一 weight/bias）→ TeCNO を回す。両枝が同一 ``c5_neck`` を共有
するため、トレーナーで ``L = w_d·L_det + w_p·L_phase``（or Kendall&Gal）を1回 backward すると
両勾配が同一 Parameter に合算される（＝結合の本体）。

設計上 forward はオーバーライドしない（単GPU・トレーナーが検出/工程を別呼びして結合）:
    loss_dict = model(images, targets)        # 検出（親のまま）
    L_phase   = model.phase_loss(gap, labels) # 工程（本クラス追加メソッド）
Kendall&Gal 用に ``log_var_d/log_var_p`` を保持（weighting='uncertainty' 時のみ）。
"""
import torch
import torch.nn.functional as F
from torch import nn

from models.detectors.relation_detr_c5neck import RelationDETRC5Neck
from models.temporal.tecno_mirror import TeCNO, smoothing_loss

SMOOTHING_WEIGHT = 0.15  # 本体 train_s4_tecno.py と同一


class RelationDETRB1MTL(RelationDETRC5Neck):
    """RelationDETRC5Neck + 共有 neck から生やす TeCNO 工程枝（B1 素朴MTL）。"""

    def __init__(self, *args, num_phases: int = 9, tecno_stages: int = 2,
                 tecno_layers: int = 8, tecno_fmaps: int = 64,
                 weighting: str = "fixed", **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.phase_head = TeCNO(
            num_stages=tecno_stages, num_layers=tecno_layers, num_f_maps=tecno_fmaps,
            in_dim=2048, num_classes=num_phases,
        )
        self.weighting = weighting
        if weighting == "uncertainty":
            # Kendall&Gal: 学習可能な log σ²（0 初期化＝重み 1 から開始）。weight_decay は除外する。
            self.log_var_d = nn.Parameter(torch.zeros(()))
            self.log_var_p = nn.Parameter(torch.zeros(()))

    def forward_phase(self, gap: torch.Tensor) -> list[torch.Tensor]:
        """凍結 GAP キャッシュ (B, 2048, T) → 共有 neck(vector) → TeCNO → 各ステージ (B, C, T)。"""
        v = self.c5_neck.forward_vector(gap.transpose(1, 2))  # (B, T, 2048)
        return self.phase_head(v.transpose(1, 2))             # (B, 2048, T) -> TeCNO

    def phase_loss(self, gap: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """工程損失 = Σ_stage (CE + 0.15·smoothing)。本体 train_s4_tecno.py と同式。

        gap: (1, 2048, T) / labels: (T,)。最終ステージ argmax を推論に使う（forward_phase 参照）。
        """
        outs = self.forward_phase(gap)
        return sum(
            F.cross_entropy(o[0].T, labels) + SMOOTHING_WEIGHT * smoothing_loss(o)
            for o in outs
        )
