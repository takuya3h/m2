"""Relation-DETR + Phase→Det FiLM 注入（STEP B Tier-1 / T1b・①予測相互作用 L3）。

MT4MTL-KD-style Phase→Det（§4.6 双方向の Phase→Det 半分）の自前実装。凍結 S4 工程モデルの
per-frame 事後分布（phase context, 9-d）を条件に、検出器の C5 特徴を **FiLM（feature-wise
linear modulation）** で変調する。注入点は ``get_multi_levels`` の C5（c5_neck と同じスロット）。

FiLM は **zero-init**（γ_raw=0,β_raw=0 → γ=1,β=0 ＝恒等）。よって s0_016 から warm-start した
直後は S0-frozen と厳密に一致し、fine-tune で初めて phase 変調を学習する（Δ_detection が
「注入の効果」を測れる）。c_phase は forward 前に ``model.set_phase_context(ctx)`` でセットする
（バッチ画像順と一致させること。DETR preprocess は順序を保つ）。

C5LinearNeck と同様、.venv-relation-detr は egosurgery を持たないため自己完結で実装する。
"""
import torch
from models.detectors.relation_detr import RelationDETR
from torch import nn
from torch.nn import functional as NF


class PhaseFiLM(nn.Module):
    """phase context (B, P) → C5 チャネル(dim) の FiLM パラメータ (γ, β)。zero-init で恒等。

    γ = 1 + γ_raw, β = β_raw。最終層 zero-init により初期は γ=1,β=0（恒等変調）。
    """

    def __init__(self, num_phases: int = 9, dim: int = 2048, hidden: int = 64) -> None:
        super().__init__()
        self.dim = int(dim)
        self.mlp = nn.Sequential(
            nn.Linear(num_phases, hidden),
            nn.ReLU(inplace=True),
            nn.Linear(hidden, 2 * dim),
        )
        nn.init.zeros_(self.mlp[-1].weight)
        nn.init.zeros_(self.mlp[-1].bias)

    def forward(self, c5: torch.Tensor, ctx: torch.Tensor) -> torch.Tensor:
        # c5: (B, dim, H, W) / ctx: (B, P)
        gamma_beta = self.mlp(ctx)                              # (B, 2*dim)
        gamma, beta = gamma_beta[:, : self.dim], gamma_beta[:, self.dim :]
        gamma = (1.0 + gamma).unsqueeze(-1).unsqueeze(-1)       # (B, dim, 1, 1)
        beta = beta.unsqueeze(-1).unsqueeze(-1)
        return gamma * c5 + beta


class RelationDETRPhaseFiLM(RelationDETR):
    """RelationDETR に Phase→Det FiLM 注入を加えた派生検出器（T1b）。"""

    def __init__(self, *args, num_phases: int = 9, c5_dim: int = 2048, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.phase_film = PhaseFiLM(num_phases=num_phases, dim=c5_dim)
        self._phase_ctx = None  # forward 前に set_phase_context でセット

    def set_phase_context(self, ctx: torch.Tensor) -> None:
        """次の forward で使う phase context (B, P) を登録する（画像順と一致させる）。"""
        self._phase_ctx = ctx

    def _apply_phase_film(self, feats):
        """backbone の最終レベル（C5）にのみ FiLM を当てる（dict/list 両対応）。"""
        if self._phase_ctx is None:
            return feats  # context 未設定なら恒等（=対照/評価フォールバック）
        if isinstance(feats, dict):
            keys = list(feats.keys())
            feats[keys[-1]] = self.phase_film(feats[keys[-1]], self._phase_ctx)
            return feats
        feats = list(feats)
        feats[-1] = self.phase_film(feats[-1], self._phase_ctx)
        return feats

    def get_multi_levels(self, images, mask):
        # DETRDetector.get_multi_levels と同一だが backbone→neck の間に Phase→Det FiLM を挿入。
        multi_level_feats = self.backbone(images.tensors)
        multi_level_feats = self._apply_phase_film(multi_level_feats)   # ★ C5 のみ・phase 条件
        multi_level_feats = self.neck(multi_level_feats)

        def interp_mask(size):
            return NF.interpolate(mask[None], size=size)[0].to(torch.bool)

        multi_level_masks = [interp_mask(feat.shape[-2:]) for feat in multi_level_feats]
        multi_level_pos_embeds = [self.position_embedding(m) for m in multi_level_masks]
        return multi_level_feats, multi_level_masks, multi_level_pos_embeds
