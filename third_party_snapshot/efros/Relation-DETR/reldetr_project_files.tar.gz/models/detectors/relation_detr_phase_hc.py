"""H-C-v1 detector: T1b-CA + Entropy gate（§7.2 H-C コアの最小実装・ゲート単体寄与の分離）。

`RelationDETRPhaseCrossAttn`（T1b-CA, §4.6 primary）から派生し、forward 前に phase posterior
の entropy を計算して **gate ∈ [0,1] を per-frame で乗算** する。これにより:
- 高確信 frame（H≈0 → gate→1）: T1b-CA と同じ強さで phase context を注入
- 低確信 frame（H≈1 → gate→0）: phase 文脈ノイズを排除（zero-ctx 相当に減衰）
→ §3.2 の「FiLM/CA は一様で標的化不能」のうち、**時間方向の選択性**を追加する H-C コア最小寄与。

gate の定式:
    H = -Σ p_i log p_i / log(K=9)   ∈ [0,1]  （K=9 工程・自然対数で正規化）
    gate = sigmoid((τ - H) * scale)            （τ=0.5 中庸・scale=10 で sharp）
    gated_ctx = ctx * gate                      （broadcast 乗算）

H-C-v1 の比較プロトコル:
- vs T1b-CA-inj (3-seed) : 差分 = entropy gate の有無 → gate 単体寄与
- vs S0-frozen warm-start (per-seed measure-only) : Δ_detection 主指標
- 対照 (zero-ctx, ctx=0)  : 注入容量・fine-tune の効果分離

実装は `set_phase_context` のオーバーライド 1 点のみ。decoder 層自体は phase-CA を流用。
"""
import torch
import torch.nn.functional as F

from models.detectors.relation_detr_phasecrossattn import RelationDETRPhaseCrossAttn


class RelationDETRPhaseHC(RelationDETRPhaseCrossAttn):
    """T1b-CA + per-frame entropy gate（H-C コア最小実装・ゲート単体寄与の分離）。

    parameters / state_dict layout は親 (T1b-CA) と完全同一なので、T1b-CA の ckpt を
    そのまま warm-start できる（gate は学習なし・閉形式）。
    """

    def __init__(self, *args, gate_tau: float = 0.5, gate_scale: float = 10.0, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        # gate のハイパーパラメータ（学習なし、再現性のため buffer に保持）。
        self.register_buffer("_gate_tau", torch.tensor(float(gate_tau)))
        self.register_buffer("_gate_scale", torch.tensor(float(gate_scale)))
        # 直近の gate 統計（log 用、勾配経路には乗らない）。
        self._last_gate_mean = None
        self._last_entropy_mean = None

    @staticmethod
    def _phase_entropy_normalized(ctx: torch.Tensor) -> torch.Tensor:
        """phase posterior (B, K) → 正規化エントロピー H ∈ [0,1]（K=ctx.shape[-1]）。

        ctx は学習済み S4 TeCNO の softmax 出力なので合計 1 だが、数値安定のため
        p = softmax(log(ctx + eps)) で再正規化はせず、clamp + 1/log(K) で対処。
        """
        eps = 1e-8
        K = ctx.shape[-1]
        p = ctx.clamp_min(eps)
        H = -(p * p.log()).sum(dim=-1) / float(torch.log(torch.tensor(float(K))))
        return H.clamp(0.0, 1.0)  # 数値誤差で 1.0 超え/負を防ぐ

    def set_phase_context(self, ctx) -> None:
        """次の forward で使う phase context (B,P) に entropy gate を適用してから親へ委譲。

        - ctx is None → そのまま親に渡す（eval/対照フォールバック・恒等）
        - ctx is zero（zero-ctx 対照）→ entropy が log(K)/log(K)=1.0 → gate≈0 → ctx*gate≈0
          （zero-ctx のまま流れる）。よって zero-ctx 対照は T1b-CA-zero-ctx と挙動一致。
        """
        if ctx is None:
            super().set_phase_context(None)
            return
        H = self._phase_entropy_normalized(ctx)                     # (B,)
        gate = torch.sigmoid((self._gate_tau - H) * self._gate_scale)  # (B,)
        gated = ctx * gate.unsqueeze(-1)                              # (B, K)
        # 統計を更新（勾配なし）
        with torch.no_grad():
            self._last_entropy_mean = float(H.mean())
            self._last_gate_mean = float(gate.mean())
        super().set_phase_context(gated)
