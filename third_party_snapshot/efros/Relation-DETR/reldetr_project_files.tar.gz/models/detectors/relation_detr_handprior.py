"""Relation-DETR + Hand-mask→Det 注入（L2 oracle_hand2det 4ch / L1a oracle_hti2det 5ch の機構）。

手 mask を検出器 C5（backbone 最終レベル・stride 1/32・2048ch）に **zero-init 1x1 conv の加算残差**
として注入する。注入点は RelationDETRPhaseFiLM と同一スロット（C5・neck の直前）で、機構は
「残差加算」に限定する。L2/L1a は **同一機構**で、入力チャネル数（4ch / 5ch）だけを切り替える
（機構を変えると L2 と L1a の交絡になるため）。

  入力チャネル構成（リーク境界をコードで強制）:
    ch0..3 : 手クラス4ch の低解像度 prior map          … Tier0 = 手 mask のみ = 安全(L2)
    ch4    : per-hand 把持フラグ 1ch（手側属性 bool）    … Tier1 = ＋把持フラグ = 安全(L1a)

  ★ リーク境界（厳守・下記 TIER3 GUARD 参照）:
    - Tier2（接触領域 hand∩tool）は **今回実装しない**。
    - Tier3（tool mask / tool bbox / tool クラス）は **禁止**。この注入経路に渡るテンソルは
      手側情報（手 mask ＋ 把持フラグ）のみで、tool 由来の情報が混入する余地がコード上ない。
      HandPriorInject.forward が受け取るのは呼び出し側が組んだ手側チャネルだけであり、この
      モジュールは tool マスク/bbox/クラスを参照・受理・生成しない。hand_channels は 4 か 5 に
      固定され、6ch 以上（接触/tool 追加）は assert で弾く。

zero-init のため warm-start 直後は残差 0＝恒等で、S0-frozen（検出器 warm-start 元）と厳密一致する。
bias を持たせない（bias=False）ことで「注入テンソル=0 → 残差 0 かつ注入経路の勾配 0」が厳密に
成り立ち、配線検証（注入経路のみ非ゼロ勾配・0 対照で勾配 0）が bit で判定できる。

C5LinearNeck / PhaseFiLM と同様、.venv-relation-detr は egosurgery を持たないため自己完結で実装する。
"""
import torch
from models.detectors.relation_detr import RelationDETR
from torch import nn
from torch.nn import functional as NF

# この注入経路が受理する手側チャネル構成。tool（Tier3）を足す拡張は禁止。
HAND_ONLY_CHANNELS = 4   # Tier0 / L2: 手クラス4ch prior map（手 mask のみ）
HAND_GRASP_CHANNELS = 5  # Tier1 / L1a: ＋把持フラグ1ch（手側属性 bool）


class HandPriorInject(nn.Module):
    """手 mask prior (B, C_hand, Hm, Wm) → C5 (B, dim, H, W) への zero-init 残差。

    手 mask を C5 の空間解像度（stride 1/32）へ downsample し、zero-init の 1x1 conv（bias 無し）で
    dim チャネルへ射影して C5 に加算する。init では conv 重み=0 なので残差=0（恒等）。

    ★ TIER3 GUARD: ``hand`` は手側チャネル（手 mask 4ch ＋ 任意で把持フラグ1ch）のみ。tool mask/
    bbox/クラスはこのモジュールに一切渡らない（呼び出し側が組む手側テンソルだけを受ける）。
    hand_channels は 4 or 5 に固定し、6ch 以上（接触領域=Tier2 や tool=Tier3 の追加）は禁止。
    """

    def __init__(self, hand_channels: int = 4, dim: int = 2048) -> None:
        super().__init__()
        if hand_channels not in (HAND_ONLY_CHANNELS, HAND_GRASP_CHANNELS):
            # Tier2（接触）や Tier3（tool）を暗黙に許すチャネル拡張を弾く。
            raise ValueError(
                f"hand_channels は {HAND_ONLY_CHANNELS}(L2) か {HAND_GRASP_CHANNELS}(L1a) のみ許可"
                f"（tool/接触の混入禁止・Tier3 GUARD）。got={hand_channels}"
            )
        self.hand_channels = int(hand_channels)
        self.dim = int(dim)
        # bias=False: 注入テンソル=0 のとき残差=0 かつ勾配=0 を厳密に成立させる（配線検証の前提）。
        self.proj = nn.Conv2d(self.hand_channels, self.dim, kernel_size=1, bias=False)
        nn.init.zeros_(self.proj.weight)  # zero-init 恒等（warm-start 直後 = S0-frozen 一致）

    def forward(self, c5: torch.Tensor, hand: torch.Tensor) -> torch.Tensor:
        # c5: (B, dim, H, W) / hand: (B, C_hand, Hm, Wm)
        if hand.shape[1] != self.hand_channels:
            raise ValueError(
                f"hand prior のチャネル数不一致: got {hand.shape[1]}, expected {self.hand_channels}"
            )
        hand = hand.to(dtype=c5.dtype, device=c5.device)
        if hand.shape[-2:] != c5.shape[-2:]:
            # 手 mask(H×W) → backbone stride(1/32=C5)へ downsample（面積平均で prior を保つ）。
            hand = NF.interpolate(hand, size=c5.shape[-2:], mode="area")
        return c5 + self.proj(hand)  # zero-init proj → init では残差 0（恒等）


class RelationDETRHandPrior(RelationDETR):
    """RelationDETR に Hand-mask→Det 注入（C5 残差）を加えた派生検出器（L2 / L1a 共通機構）。"""

    def __init__(self, *args, hand_channels: int = 4, c5_dim: int = 2048, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.hand_prior = HandPriorInject(hand_channels=hand_channels, dim=c5_dim)
        self._hand_input = None  # forward 前に set_hand_prior でセット

    def set_hand_prior(self, hand: torch.Tensor) -> None:
        """次の forward で使う手 mask prior (B, C_hand, Hm, Wm) を登録する（画像順と一致させる）。"""
        self._hand_input = hand

    def _apply_hand_prior(self, feats):
        """backbone の最終レベル（C5）にのみ手 mask 残差を当てる（dict/list 両対応）。"""
        if self._hand_input is None:
            return feats  # 未設定なら恒等（=注入無しフォールバック）
        if isinstance(feats, dict):
            keys = list(feats.keys())
            feats[keys[-1]] = self.hand_prior(feats[keys[-1]], self._hand_input)
            return feats
        feats = list(feats)
        feats[-1] = self.hand_prior(feats[-1], self._hand_input)
        return feats

    def get_multi_levels(self, images, mask):
        # DETRDetector.get_multi_levels と同一だが backbone→neck の間に Hand-mask 残差を挿入。
        multi_level_feats = self.backbone(images.tensors)
        multi_level_feats = self._apply_hand_prior(multi_level_feats)   # ★ C5 のみ・手 mask 条件
        multi_level_feats = self.neck(multi_level_feats)

        def interp_mask(size):
            return NF.interpolate(mask[None], size=size)[0].to(torch.bool)

        multi_level_masks = [interp_mask(feat.shape[-2:]) for feat in multi_level_feats]
        multi_level_pos_embeds = [self.position_embedding(m) for m in multi_level_masks]
        return multi_level_feats, multi_level_masks, multi_level_pos_embeds
