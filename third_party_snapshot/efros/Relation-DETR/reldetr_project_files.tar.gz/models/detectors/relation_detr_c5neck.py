"""Relation-DETR + 共有 C5 線形 neck（STEP B / ②特徴レベル系統の検出枝）。

研究本体（egosurgery_multitask）の比較の三角形 ②系統で使う共有 trainable neck を、
検出経路（Relation-DETR）に挿入する。確定事項（2026-06-18）:
    - 共有 neck は **C5 のみ**に置く。
    - 形は **1×1 線形・2048→2048・残差・zero-init**（masked-GAP と可換）。

挿入点は ``get_multi_levels`` の backbone→neck(ChannelMapper) の**間**。ChannelMapper は
C3/C4/C5 をまとめて 256×4lv に写すため、「C5 のみ」を守るには ChannelMapper の手前で
最終レベル（C5）にだけ neck を当てる。c5_neck は **トップレベル module**（名前 ``c5_neck.*``）
として持つ。optimizer の ``finetune_backbone_and_linear_projection`` は全 named_parameters を
走査し catch-all (other/other_norm) を持つため、c5_neck は主 LR で学習対象になる。

C5LinearNeck は本体 ``src/egosurgery/models/necks/c5_linear_neck.py`` の最小ミラー。
.venv-relation-detr は egosurgery パッケージを持たないため、検出枝が必要とする spatial 適用
のみを自己完結で複製する（挙動は本体と同一: weight=0/bias=0 初期化で恒等、残差）。
"""
import torch
from torch import nn
from torch.nn import functional as NF

from models.detectors.relation_detr import RelationDETR


class C5LinearNeck(nn.Module):
    """C5 spatial に作用する 1×1 線形 neck（残差・zero-init）。本体 C5LinearNeck の spatial 版。"""

    def __init__(self, dim: int = 2048, residual: bool = True, zero_init: bool = True) -> None:
        super().__init__()
        self.dim = int(dim)
        self.residual = bool(residual)
        self.weight = nn.Parameter(torch.empty(self.dim, self.dim))
        self.bias = nn.Parameter(torch.empty(self.dim))
        if zero_init:
            nn.init.zeros_(self.weight)
            nn.init.zeros_(self.bias)
        else:
            nn.init.kaiming_uniform_(self.weight, a=5 ** 0.5)
            nn.init.zeros_(self.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, dim, H, W)
        w = self.weight.unsqueeze(-1).unsqueeze(-1)       # (dim, dim, 1, 1)
        out = NF.conv2d(x, w, self.bias)
        return x + out if self.residual else out

    def forward_vector(self, v: torch.Tensor) -> torch.Tensor:  # (..., dim)
        """GAP 後ベクトルへの適用（工程枝）。spatial の forward と同一 weight/bias を共有。

        masked-GAP 可換性（``GAP(N(C5)) == N(GAP(C5))``）より、検出枝の C5 spatial neck と
        同一定義。B1 ではこの forward_vector と spatial forward が同じ ``self.weight/bias`` を
        使うため、検出損失と工程損失の勾配が同一 Parameter に合算される（＝結合の本体）。
        """
        out = NF.linear(v, self.weight, self.bias)
        return v + out if self.residual else out


class RelationDETRC5Neck(RelationDETR):
    """RelationDETR に共有 C5 線形 neck を挿入した派生検出器（②系統）。"""

    def __init__(self, *args, c5_dim: int = 2048, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.c5_neck = C5LinearNeck(dim=c5_dim)

    def _apply_c5_neck(self, feats):
        """backbone の最終レベル（C5）にのみ neck を当てる（dict/list 両対応）。"""
        if isinstance(feats, dict):
            keys = list(feats.keys())
            feats[keys[-1]] = self.c5_neck(feats[keys[-1]])
            return feats
        feats = list(feats)
        feats[-1] = self.c5_neck(feats[-1])
        return feats

    def get_multi_levels(self, images, mask):
        # DETRDetector.get_multi_levels と同一だが backbone→neck の間に C5 neck を挿入する。
        multi_level_feats = self.backbone(images.tensors)
        multi_level_feats = self._apply_c5_neck(multi_level_feats)   # ★ C5 のみ
        multi_level_feats = self.neck(multi_level_feats)

        def interp_mask(size):
            return NF.interpolate(mask[None], size=size)[0].to(torch.bool)

        multi_level_masks = [interp_mask(feat.shape[-2:]) for feat in multi_level_feats]
        multi_level_pos_embeds = [self.position_embedding(m) for m in multi_level_masks]
        return multi_level_feats, multi_level_masks, multi_level_pos_embeds
