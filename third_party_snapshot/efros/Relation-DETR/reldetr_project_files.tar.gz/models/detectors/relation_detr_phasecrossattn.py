"""T1b-CA detector: RelationDETR に Phase→Det cross-attention 注入を加えた派生検出器（§4.6 primary）。

relation_detr_resnet50_egosurgery.py（S0-frozen の検出器）との **唯一の差**は、decoder 層を
``RelationTransformerDecoderLayerPhaseCA`` にし、phase 事後(9-d)を 1 トークンに埋め込んで各 decoder 層の
cross-attention 副層へ注入する点。backbone(凍結)/neck/encoder/criterion/postprocessor は S0-frozen と
完全一致 → warm-start で同一土台（§6）。phase 副層は zero-init=恒等なので warm-start 直後は S0-frozen と
厳密一致する。

``set_phase_context(ctx)`` を forward 前に呼ぶ（バッチ画像順と一致させること。DETR preprocess は順序保持）。
ctx=(B,P) を 1 トークン(B,1,embed)へ埋め込み、各 phase-CA decoder 層の ``_c_phase`` に配る。ctx=None なら
None を配り、各層は注入を skip＝恒等（eval/対照フォールバック）。zero-ctx 対照は ctx=0（定数トークン）で
T1b(FiLM) と同様に「注入容量・fine-tune の効果」と「phase 信号の効果」を分離する。
"""
from models.bricks.relation_decoder_phaseca import (
    RelationTransformerDecoderLayerPhaseCA,
)
from models.detectors.relation_detr import RelationDETR
from torch import nn


class RelationDETRPhaseCrossAttn(RelationDETR):
    """RelationDETR に Phase→Det cross-attention 注入を加えた派生検出器（T1b-CA）。"""

    def __init__(self, *args, num_phases: int = 9, embed_dim: int = 256, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        # phase 事後(P) → c_phase token(embed)。恒等性は phase_attn.out_proj の zero-init が担保するため
        # この埋め込みは通常初期化でよい（初期は下流の注入寄与が 0 なので出力に影響しない）。
        self.phase_embed = nn.Linear(num_phases, embed_dim)
        self._phase_ctx = None
        # decoder の phase-CA 層を一度だけ収集（transformer は super().__init__ で構築済み）。
        self._phase_layers = [
            m for m in self.modules() if isinstance(m, RelationTransformerDecoderLayerPhaseCA)
        ]

    def set_phase_context(self, ctx) -> None:
        """次の forward で使う phase context (B,P) を登録し、c_phase token を各 decoder 層へ配る。

        ctx は学習ステップ内（autograd 有効）で渡されるため、token 計算は phase_embed まで勾配が流れる。
        """
        self._phase_ctx = ctx
        token = None if ctx is None else self.phase_embed(ctx).unsqueeze(1)  # (B,1,embed)
        for layer in self._phase_layers:
            layer._c_phase = token
