# Hand-mask→Det model config（L2 oracle_hand2det 4ch / L1a oracle_hti2det 5ch の共通機構）。
#
# relation_detr_resnet50_egosurgery.py（S0-frozen の検出器）との**唯一の差**は、検出器を
# RelationDETRHandPrior にして C5 に手 mask 条件の zero-init 残差注入を加える点。backbone(凍結) /
# neck / transformer / criterion / postprocessor は S0-frozen と完全一致 → warm-start で
# S0-frozen と同一土台。注入は zero-init=恒等なので warm-start 直後は S0-frozen と一致。
#
# 4ch(L2) / 5ch(L1a) の切替は環境変数 HAND2DET_HAND_CHANNELS（既定 4）で行う（機構は不変・
# 入力チャネルのみ切替。L2 と L1a を同一機構に固定して交絡を避ける）。
import os

from models.backbones.resnet import ResNetBackbone
from models.bricks.misc import FrozenBatchNorm2d
from models.bricks.position_encoding import PositionEmbeddingSine
from models.bricks.post_process import PostProcess
from models.bricks.relation_transformer import (
    RelationTransformer,
    RelationTransformerDecoder,
    RelationTransformerDecoderLayer,
    RelationTransformerEncoder,
    RelationTransformerEncoderLayer,
)
from models.bricks.set_criterion import HybridSetCriterion
from models.detectors.relation_detr_handprior import RelationDETRHandPrior
from models.matcher.hungarian_matcher import HungarianMatcher
from models.necks.channel_mapper import ChannelMapper
from torch import nn

embed_dim = 256
num_classes = 15
num_queries = 900
hybrid_num_proposals = 1500
hybrid_assign = 6
num_feature_levels = 4
transformer_enc_layers = 6
transformer_dec_layers = 6
num_heads = 8
dim_feedforward = 2048
# 4ch(L2: 手 mask のみ) / 5ch(L1a: ＋把持フラグ)。既定 4。tool/接触の追加は model 側で禁止。
hand_channels = int(os.environ.get("HAND2DET_HAND_CHANNELS", "4"))

position_embedding = PositionEmbeddingSine(
    embed_dim // 2, temperature=10000, normalize=True, offset=-0.5
)
backbone = ResNetBackbone(
    "resnet50",
    norm_layer=FrozenBatchNorm2d,
    return_indices=(1, 2, 3),
    freeze_indices=(0, 1, 2, 3),
)
neck = ChannelMapper(
    in_channels=backbone.num_channels, out_channels=embed_dim, num_outs=num_feature_levels,
)
transformer = RelationTransformer(
    encoder=RelationTransformerEncoder(
        encoder_layer=RelationTransformerEncoderLayer(
            embed_dim=embed_dim, n_heads=num_heads, dropout=0.0,
            activation=nn.ReLU(inplace=True), n_levels=num_feature_levels,
            n_points=4, d_ffn=dim_feedforward,
        ),
        num_layers=transformer_enc_layers,
    ),
    decoder=RelationTransformerDecoder(
        decoder_layer=RelationTransformerDecoderLayer(
            embed_dim=embed_dim, n_heads=num_heads, dropout=0.0,
            activation=nn.ReLU(inplace=True), n_levels=num_feature_levels,
            n_points=4, d_ffn=dim_feedforward,
        ),
        num_layers=transformer_dec_layers, num_classes=num_classes,
    ),
    num_classes=num_classes, num_feature_levels=num_feature_levels,
    two_stage_num_proposals=num_queries, hybrid_num_proposals=hybrid_num_proposals,
)
matcher = HungarianMatcher(cost_class=2, cost_bbox=5, cost_giou=2, focal_alpha=0.25, focal_gamma=2.0)

weight_dict = {"loss_class": 1, "loss_bbox": 5, "loss_giou": 2}
weight_dict.update({"loss_class_dn": 1, "loss_bbox_dn": 5, "loss_giou_dn": 2})
aux_weight_dict = {}
for i in range(transformer.decoder.num_layers - 1):
    aux_weight_dict.update({k + f"_{i}": v for k, v in weight_dict.items()})
weight_dict.update(aux_weight_dict)
weight_dict.update({"loss_class_enc": 1, "loss_bbox_enc": 5, "loss_giou_enc": 2})
weight_dict.update({k + "_hybrid": v for k, v in weight_dict.items()})

criterion = HybridSetCriterion(
    num_classes=num_classes, matcher=matcher, weight_dict=weight_dict, alpha=0.25, gamma=2.0
)

postprocessor = PostProcess(
    select_box_nums_for_evaluation=300, nms_iou_threshold=-1, confidence_score=-1,
)

model = RelationDETRHandPrior(
    backbone=backbone, neck=neck, position_embedding=position_embedding,
    transformer=transformer, criterion=criterion, postprocessor=postprocessor,
    num_classes=num_classes, num_queries=num_queries, hybrid_assign=hybrid_assign,
    denoising_nums=100, min_size=800, max_size=1333,
    hand_channels=hand_channels, c5_dim=2048,
)
