# H-C-v1 Phase→Det model config（T1b-CA + entropy gate, §7.2 H-C コア最小実装）。
#
# t1b_ca.py との **唯一の差**は検出器 class のみ:
#   - RelationDETRPhaseCrossAttn → RelationDETRPhaseHC（entropy gate を追加）
# decoder 層は phase-CA をそのまま流用（state_dict layout 一致 → T1b-CA ckpt も warm-start 可能）。
# backbone(凍結)/neck/encoder/transformer/criterion/postprocessor は S0-frozen・T1b-CA と完全一致。
from models.backbones.resnet import ResNetBackbone
from models.bricks.misc import FrozenBatchNorm2d
from models.bricks.position_encoding import PositionEmbeddingSine
from models.bricks.post_process import PostProcess
from models.bricks.relation_decoder_phaseca import (
    RelationTransformerDecoderLayerPhaseCA,
)
from models.bricks.relation_transformer import (
    RelationTransformer,
    RelationTransformerDecoder,
    RelationTransformerEncoder,
    RelationTransformerEncoderLayer,
)
from models.bricks.set_criterion import HybridSetCriterion
from models.detectors.relation_detr_phase_hc import RelationDETRPhaseHC
from models.matcher.hungarian_matcher import HungarianMatcher
from models.necks.channel_mapper import ChannelMapper
from torch import nn

embed_dim = 256
num_classes = 15
num_queries = 900
hybrid_num_proposals = 1500
hybrid_assign = 6
num_feature_levels = 4
transformer_enc_layers = 6
transformer_dec_layers = 6
num_heads = 8
dim_feedforward = 2048
num_phases = 9

# Entropy gate ハイパー（H-C-v1 既定 = データドリブン決定）。
# 実 phase ctx（data/processed/phase_context/relation_detr_seed42/{train,val,test}_phasectx.npz）の
# normalized entropy H は train mean=0.126 / median=0.087 / 95%ile=0.346 で非常に低い（S4 TeCNO は
# high-confidence な出力）。τ=0.5 だと 98% frame で gate≈1（H-C → T1b-CA に退化）→ gate が機能しない。
# よって train H 分布のやや上側を中庸点とする:
#   τ=0.15（gate=0.5 の境界） / scale=20（H=0.05/0.30 で gate=0.88/0.05 と明確に分離）
# 期待動作: 高 confidence frame（H<0.1, 工程中央）= gate>0.7 で注入、低 confidence frame
# （H>0.2, 工程遷移近傍）= gate<0.3 で抑制 → 「確信時のみ注入」を実データ分布に合わせる。
gate_tau = 0.15
gate_scale = 20.0

position_embedding = PositionEmbeddingSine(
    embed_dim // 2, temperature=10000, normalize=True, offset=-0.5
)
backbone = ResNetBackbone(
    "resnet50",
    norm_layer=FrozenBatchNorm2d,
    return_indices=(1, 2, 3),
    freeze_indices=(0, 1, 2, 3),
)
neck = ChannelMapper(
    in_channels=backbone.num_channels, out_channels=embed_dim, num_outs=num_feature_levels,
)
transformer = RelationTransformer(
    encoder=RelationTransformerEncoder(
        encoder_layer=RelationTransformerEncoderLayer(
            embed_dim=embed_dim, n_heads=num_heads, dropout=0.0,
            activation=nn.ReLU(inplace=True), n_levels=num_feature_levels,
            n_points=4, d_ffn=dim_feedforward,
        ),
        num_layers=transformer_enc_layers,
    ),
    decoder=RelationTransformerDecoder(
        decoder_layer=RelationTransformerDecoderLayerPhaseCA(
            embed_dim=embed_dim, n_heads=num_heads, dropout=0.0,
            activation=nn.ReLU(inplace=True), n_levels=num_feature_levels,
            n_points=4, d_ffn=dim_feedforward,
        ),
        num_layers=transformer_dec_layers, num_classes=num_classes,
    ),
    num_classes=num_classes, num_feature_levels=num_feature_levels,
    two_stage_num_proposals=num_queries, hybrid_num_proposals=hybrid_num_proposals,
)
matcher = HungarianMatcher(cost_class=2, cost_bbox=5, cost_giou=2, focal_alpha=0.25, focal_gamma=2.0)

weight_dict = {"loss_class": 1, "loss_bbox": 5, "loss_giou": 2}
weight_dict.update({"loss_class_dn": 1, "loss_bbox_dn": 5, "loss_giou_dn": 2})
aux_weight_dict = {}
for i in range(transformer.decoder.num_layers - 1):
    aux_weight_dict.update({k + f"_{i}": v for k, v in weight_dict.items()})
weight_dict.update(aux_weight_dict)
weight_dict.update({"loss_class_enc": 1, "loss_bbox_enc": 5, "loss_giou_enc": 2})
weight_dict.update({k + "_hybrid": v for k, v in weight_dict.items()})

criterion = HybridSetCriterion(
    num_classes=num_classes, matcher=matcher, weight_dict=weight_dict, alpha=0.25, gamma=2.0
)

postprocessor = PostProcess(
    select_box_nums_for_evaluation=300, nms_iou_threshold=-1, confidence_score=-1,
)

model = RelationDETRPhaseHC(
    backbone=backbone, neck=neck, position_embedding=position_embedding,
    transformer=transformer, criterion=criterion, postprocessor=postprocessor,
    num_classes=num_classes, num_queries=num_queries, hybrid_assign=hybrid_assign,
    denoising_nums=100, min_size=800, max_size=1333,
    num_phases=num_phases, embed_dim=embed_dim,
    gate_tau=gate_tau, gate_scale=gate_scale,
)
