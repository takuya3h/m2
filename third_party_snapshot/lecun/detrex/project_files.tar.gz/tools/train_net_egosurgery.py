#!/usr/bin/env python3
"""train_net_egosurgery.py — detrex 本体 train_net を EgoSurgery 用にラップ。

detrex の tools/train_net.py をそのまま使うと EgoSurgery データセットが
DatasetCatalog に未登録なので、本ラッパで register_coco_instances する。

重要 (spawn 対応): detectron2 の launch() は DDP ワーカーを spawn で起動し、
対象関数を pickle して子へ渡す。ネスト関数は pickle 不可なので、
launch に渡す関数 (main_with_register) と登録関数はモジュールトップレベルに置く。
さらに spawn された子プロセスはこのモジュールを __mp_main__ として再 import するため、
登録はモジュール import 時 (トップレベル) にも実行しておく。

使い方 (detrex repo ルートを cwd / PYTHONPATH に):
  python tools/train_net_egosurgery.py \
      --config-file <...>_egosurgery.py --num-gpus 2 \
      train.output_dir=/tmp/work train.seed=42
"""
import sys
from pathlib import Path

# detrex 本体 train_net を同じ tools/ から import 可能にする。
sys.path.insert(0, str(Path(__file__).resolve().parent))

from detectron2.data.datasets import register_coco_instances  # noqa: E402

EGOSURGERY_CLASSES = [
    "Bipolar Forceps", "Electric Cautery", "Forceps", "Gauze", "Hook",
    "Mouth Gag", "Needle Holders", "Raspatory", "Retractor", "Scalpel",
    "Scissors", "Skewer", "Suction Cannula", "Syringe", "Tweezers",
]
_ANN = "/home/ubuntu/slocal2/m2/data/annotations/egosurgery_tool"
_IMG = "/home/ubuntu/slocal2/m2/data/raw/ego"


def register_egosurgery():
    """EgoSurgery train/val/test を DatasetCatalog に登録 (未登録時のみ)。"""
    from detectron2.data import DatasetCatalog, MetadataCatalog

    for split in ("train", "val", "test"):
        name = f"egosurgery_{split}"
        if name in DatasetCatalog.list():
            continue
        register_coco_instances(name, {}, f"{_ANN}/instances_{split}.json", _IMG)
        MetadataCatalog.get(name).thing_classes = list(EGOSURGERY_CLASSES)


# spawn 子プロセスはこのモジュールを再 import する。import 時に登録しておくことで
# 子プロセスでも DatasetCatalog に EgoSurgery が入る。
register_egosurgery()

import train_net as detrex_train_net  # noqa: E402


def main_with_register(args):
    """登録を保証してから detrex 本体 main を呼ぶ (トップレベル = pickle 可能)。"""
    register_egosurgery()
    return detrex_train_net.main(args)


if __name__ == "__main__":
    from detectron2.engine import default_argument_parser, launch  # noqa: E402

    args = default_argument_parser().parse_args()
    launch(
        main_with_register,
        args.num_gpus,
        num_machines=args.num_machines,
        machine_rank=args.machine_rank,
        dist_url=args.dist_url,
        args=(args,),
    )
