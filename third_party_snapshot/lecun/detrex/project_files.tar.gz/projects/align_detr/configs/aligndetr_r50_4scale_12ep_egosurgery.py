# Align-DETR (k=2) R50 4scale 12ep, EgoSurgery-Tool 適応版 (detrex lazy config)。
# 親: aligndetr_k=2_r50_4scale_12ep。Stable-DINO の egosurgery 適応と同方針で揃える:
#   - model / criterion / matcher の num_classes 80 -> 15
#   - dataloader を EgoSurgery 登録データセット (egosurgery_{train,val}) へ
#   - 学習スケジュール: effective_bs=4 (2GPU x per-gpu 2), 12ep = 28980 iter,
#     lr step=26565 (11ep相当), eval/checkpoint=2415 iter (1ep) ごと
#   - locked-down test: 他検出器と揃える (topk 方式 NMS-free, max_per_img=300)
#   - init_checkpoint: Align-DETR R50 COCO 12ep 重み (backbone+transformer をロード、
#     class_embed(80->15) は形状不一致で自動 skip = 他検出器の COCO fine-tune と同条件)。
#     ※ 重み DL は launcher/準備で行う。未取得時は ImageNet R-50 にフォールバック。
#   - wandb track 有効化 (run name は launcher が seed 別に上書き)。
# 評価条件・bs・スケジュールを S0 ベンチ (Stable-DINO/Relation-DETR 等) と一致させ、
# Δ 基準点を汚さないことを最優先する。Align-DETR は IA-BCE loss + mixed matching。
from detrex.config import get_config
from .models.aligndetr_r50 import model

dataloader = get_config("common/data/coco_detr.py").dataloader
optimizer = get_config("common/optim.py").AdamW
lr_multiplier = get_config("common/coco_schedule.py").lr_multiplier_12ep
train = get_config("common/train.py").train

# --- EgoSurgery 15 クラス ------------------------------------------------- #
# 注意: Align-DETR の MixedMatcher は num_classes を引数に取らない (スモークで
# TypeError 確認済)。matcher への num_classes 上書きはしないこと。
# model.num_classes は criterion へ参照式 "${..num_classes}" で伝播するが、
# 念のため criterion.num_classes も明示する (matcher には触れない)。
model.num_classes = 15
model.criterion.num_classes = 15
# Align-DETR の mixed matching (k=2) はそのまま (match_num/tau は親の既定を維持)。

# --- データセット (EgoSurgery 公式 split。登録は train_net ラッパが行う) --- #
dataloader.train.dataset.names = "egosurgery_train"
dataloader.test.dataset.names = "egosurgery_val"
dataloader.train.total_batch_size = 4  # 2 GPU x per-gpu 2 = effective_bs 4
dataloader.train.num_workers = 8

# --- 学習スケジュール (effective_bs=4, 12 epoch) -------------------------- #
_iters_per_epoch = 2415                          # train 9657 / bs 4
train.max_iter = _iters_per_epoch * 12           # 28980
train.eval_period = _iters_per_epoch             # 1 epoch ごと
train.checkpointer.period = _iters_per_epoch
train.log_period = 50
lr_multiplier.scheduler.milestones = [_iters_per_epoch * 11, train.max_iter]
lr_multiplier.warmup_length = 25 / train.max_iter

# --- optimizer (他検出器と揃える: AdamW lr=1e-4, backbone 0.1x, wd 1e-4) -- #
optimizer.lr = 1e-4
optimizer.betas = (0.9, 0.999)
optimizer.weight_decay = 1e-4
optimizer.params.lr_factor_func = lambda module_name: 0.1 if "backbone" in module_name else 1

# --- 勾配クリップ (detrex 既定) ------------------------------------------ #
train.clip_grad.enabled = True
train.clip_grad.params.max_norm = 0.1
train.clip_grad.params.norm_type = 2

# --- locked-down test (他検出器と評価条件を揃える) ----------------------- #
model.select_box_nums_for_evaluation = 300

# --- 初期化: Align-DETR R50 COCO 12ep 重み (準備で DL。未取得時は ImageNet) -- #
train.init_checkpoint = "/home/ubuntu/slocal2/m2/data/external/weights/aligndetr_r50_4scale_12ep_coco.pth"

train.output_dir = "/tmp/aligndetr_work"  # launcher が seed 別に上書き
train.device = "cuda"
model.device = train.device

# --- W&B track (CLAUDE.md: 全実験を必ず追跡) ----------------------------- #
train.wandb.enabled = True
train.wandb.params.project = "egosurgery_multitask"
train.wandb.params.name = "aligndetr_r50_4scale_12ep"  # launcher が seed 別に上書き
train.wandb.params.dir = "/tmp/aligndetr_work"

dataloader.evaluator.output_dir = train.output_dir
