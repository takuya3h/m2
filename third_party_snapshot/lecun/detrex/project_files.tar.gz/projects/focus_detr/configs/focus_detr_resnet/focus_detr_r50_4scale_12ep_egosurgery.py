# Focus-DETR R50 4scale 12ep, EgoSurgery-Tool 適応版 (detrex lazy config)。
# 注意: リポジトリ同梱の focus_detr_r50_4scale_12ep.py は import 重複・コメント破損が
# あるため依存せず、model を直接 import して S0 ベンチ整合の設定を最小構成で組む。
# 方針は Stable-DINO/Align-DETR の egosurgery 適応と同一:
#   - model / criterion の num_classes 80 -> 15
#   - dataloader を EgoSurgery 登録データセット (egosurgery_{train,val}) へ
#   - effective_bs=4 (2GPU x per-gpu 2), 12ep = 28980 iter, lr step=11ep, eval/ckpt=1ep
#   - locked-down test: topk NMS-free, max_per_img=300 (他検出器と一致)
#   - init_checkpoint: Focus-DETR R50 COCO 12ep 重み (準備で DL。class_embed は
#     80->15 で形状不一致 skip = 他検出器の COCO fine-tune と同条件)。未取得時 ImageNet。
#   - wandb track 有効。Focus-DETR は foreground token selection (Less is More)。
from detrex.config import get_config
from ..models.focus_detr_r50 import model

dataloader = get_config("common/data/coco_detr.py").dataloader
optimizer = get_config("common/optim.py").AdamW
lr_multiplier = get_config("common/coco_schedule.py").lr_multiplier_12ep
train = get_config("common/train.py").train

# --- EgoSurgery 15 クラス (model/criterion 両方) ------------------------- #
model.num_classes = 15
model.criterion.num_classes = 15

# --- データセット (登録は train_net ラッパが行う) ------------------------ #
dataloader.train.dataset.names = "egosurgery_train"
dataloader.test.dataset.names = "egosurgery_val"
dataloader.train.total_batch_size = 4
dataloader.train.num_workers = 8

# --- 学習スケジュール (effective_bs=4, 12 epoch) ------------------------- #
_iters_per_epoch = 2415
train.max_iter = _iters_per_epoch * 12           # 28980
train.eval_period = _iters_per_epoch
train.checkpointer.period = _iters_per_epoch
train.log_period = 50
lr_multiplier.scheduler.milestones = [_iters_per_epoch * 11, train.max_iter]
lr_multiplier.warmup_length = 25 / train.max_iter

# --- optimizer (他検出器と揃える) --------------------------------------- #
optimizer.lr = 1e-4
optimizer.betas = (0.9, 0.999)
optimizer.weight_decay = 1e-4
optimizer.params.lr_factor_func = lambda module_name: 0.1 if "backbone" in module_name else 1

# --- 勾配クリップ ------------------------------------------------------- #
train.clip_grad.enabled = True
train.clip_grad.params.max_norm = 0.1
train.clip_grad.params.norm_type = 2

# --- locked-down test --------------------------------------------------- #
model.select_box_nums_for_evaluation = 300

# --- 初期化: Focus-DETR R50 COCO 12ep 重み (準備で DL。未取得時 ImageNet) -- #
train.init_checkpoint = "/home/ubuntu/slocal2/m2/data/external/weights/focus_detr_r50_4scale_12ep_coco.pth"

train.output_dir = "/tmp/focusdetr_work"
train.device = "cuda"
model.device = train.device

# --- W&B track ---------------------------------------------------------- #
train.wandb.enabled = True
train.wandb.params.project = "egosurgery_multitask"
train.wandb.params.name = "focusdetr_r50_4scale_12ep"
train.wandb.params.dir = "/tmp/focusdetr_work"

dataloader.evaluator.output_dir = train.output_dir
