from typing import List, Tuple, Union

from torch import nn


def match_name_keywords(name: str, name_keywords: Union[Tuple, List, str]):
    if isinstance(name_keywords, str):
        name_keywords = [name_keywords]
    for b in name_keywords:
        if b in name:
            return True
    return False

def basic_param(model, lr):
    return [{"params": [p for p in model.parameters() if p.requires_grad], "lr": lr}]

def finetune_backbone_param(model, lr):
    return [
        {
            "params": [
                p for n, p in model.named_parameters() if "backbone" not in n and p.requires_grad
            ]
        },
        {
            "params": [
                p for n, p in model.named_parameters() if "backbone" in n and p.requires_grad
            ],
            "lr": lr * 0.1,
        },
    ]


def finetune_backbone_with_no_norm_weight_decay(model, lr):
    norm_classes = (
        nn.modules.batchnorm._BatchNorm,
        nn.LayerNorm,
        nn.GroupNorm,
        nn.modules.instancenorm._InstanceNorm,
        nn.LocalResponseNorm,
    )
    backbone_norm = []
    other_norm = []
    backbone = []
    other = []
    for name, module in model.named_modules():
        if next(module.children(), None):
            if "backbone" in name:
                backbone.extend(p for p in module.parameters(recurse=False) if p.requires_grad)
            else:
                other.extend(p for p in module.parameters(recurse=False) if p.requires_grad)
        elif isinstance(module, norm_classes):
            if "backbone" in name:
                backbone_norm.extend(p for p in module.parameters() if p.requires_grad)
            else:
                other_norm.extend(p for p in module.parameters() if p.requires_grad)
        else:
            if "backbone" in name:
                backbone.extend(p for p in module.parameters() if p.requires_grad)
            else:
                other.extend(p for p in module.parameters() if p.requires_grad)
    return [
        {
            "params": other,
        },
        {
            "params": backbone_norm,
            "lr": lr * 0.1,
            "weight_decay": 0,
        },
        {
            "params": other_norm,
            "weight_decay": 0,
        },
        {
            "params": backbone,
            "lr": lr * 0.1,
        },
    ]


def finetune_backbone_and_linear_projection(model, lr):
    linear_keywords = ("reference_points", "sampling_offsets")
    norm_bias_keywords = ("norm", "bias")
    backbone = []
    backbone_norm = []
    linear_projection = []
    linear_projection_norm = []
    other = []
    other_norm = []
    for name, parameters in model.named_parameters():
        if not parameters.requires_grad:
            continue
        if (
            match_name_keywords(name, "backbone")
            and not match_name_keywords(name, linear_keywords)
            and match_name_keywords(name, norm_bias_keywords)
        ):
            backbone_norm.append(parameters)
        elif (
            match_name_keywords(name, "backbone")
            and not match_name_keywords(name, linear_keywords)
            and not match_name_keywords(name, norm_bias_keywords)
        ):
            backbone.append(parameters)
        elif (
            not match_name_keywords(name, "backbone")
            and match_name_keywords(name, linear_keywords)
            and match_name_keywords(name, norm_bias_keywords)
        ):
            linear_projection_norm.append(parameters)
        elif (
            not match_name_keywords(name, "backbone")
            and match_name_keywords(name, linear_keywords)
            and not match_name_keywords(name, norm_bias_keywords)
        ):
            linear_projection.append(parameters)
        elif match_name_keywords(name, norm_bias_keywords):
            other_norm.append(parameters)
        else:
            other.append(parameters)

    return [
        {
            "params": other,
        },
        {
            "params": backbone,
            "lr": lr * 0.1,
        },
        {
            "params": backbone_norm,
            "lr": lr * 0.1,
            "weight_decay": 0,
        },
        {
            "params": linear_projection,
            "lr": lr * 0.1,
        },
        {
            "params": linear_projection_norm,
            "lr": lr * 0.1,
            "weight_decay": 0,
        },
        {
            "params": other_norm,
            "weight_decay": 0,
        },
    ]


def finetune_b1_mtl(model, lr, phase_lr=5e-4):
    """B1 素朴MTL 用 param group（②特徴レベル結合）。

    検出枝は ``finetune_backbone_and_linear_projection`` と同じ分類（共有 ``c5_neck`` は
    検出主 LR=lr の ``other`` 群に入り S0-frozen′ と一致）。工程枝（``phase_head.*``）は
    S4′ と揃えて ``phase_lr=5e-4`` の独立群、Kendall&Gal の ``log_var_*`` は weight_decay=0 の
    独立群に分離する。これにより共有 neck の LR は検出側に固定（B1 のアンカー）。
    """
    linear_keywords = ("reference_points", "sampling_offsets")
    norm_bias_keywords = ("norm", "bias")
    backbone, backbone_norm = [], []
    linear_projection, linear_projection_norm = [], []
    other, other_norm = [], []
    phase_head, log_var = [], []
    for name, parameters in model.named_parameters():
        if not parameters.requires_grad:
            continue
        # 工程枝・不確実性重みを最優先で分離（検出分類より前に振り分ける）。
        if match_name_keywords(name, "phase_head"):
            phase_head.append(parameters)
        elif match_name_keywords(name, "log_var"):
            log_var.append(parameters)
        elif (
            match_name_keywords(name, "backbone")
            and not match_name_keywords(name, linear_keywords)
            and match_name_keywords(name, norm_bias_keywords)
        ):
            backbone_norm.append(parameters)
        elif (
            match_name_keywords(name, "backbone")
            and not match_name_keywords(name, linear_keywords)
            and not match_name_keywords(name, norm_bias_keywords)
        ):
            backbone.append(parameters)
        elif (
            not match_name_keywords(name, "backbone")
            and match_name_keywords(name, linear_keywords)
            and match_name_keywords(name, norm_bias_keywords)
        ):
            linear_projection_norm.append(parameters)
        elif (
            not match_name_keywords(name, "backbone")
            and match_name_keywords(name, linear_keywords)
            and not match_name_keywords(name, norm_bias_keywords)
        ):
            linear_projection.append(parameters)
        elif match_name_keywords(name, norm_bias_keywords):
            other_norm.append(parameters)
        else:
            other.append(parameters)

    groups = [
        {"params": other},
        {"params": backbone, "lr": lr * 0.1},
        {"params": backbone_norm, "lr": lr * 0.1, "weight_decay": 0},
        {"params": linear_projection, "lr": lr * 0.1},
        {"params": linear_projection_norm, "lr": lr * 0.1, "weight_decay": 0},
        {"params": other_norm, "weight_decay": 0},
        {"params": phase_head, "lr": phase_lr},
    ]
    if log_var:  # weighting='uncertainty' のときのみ存在
        groups.append({"params": log_var, "lr": phase_lr, "weight_decay": 0})
    return groups


def finetune_t1b(model, lr, film_lr=5e-4):
    """T1b Phase→Det 用 param group（①予測相互作用・FiLM 注入）。

    検出枝は ``finetune_backbone_and_linear_projection`` と同分類（warm-start, S0-frozen と同じ
    分類で fine-tune）。注入枝（FiLM の ``phase_film.*`` / CA の ``phase_embed|phase_attn|phase_norm.*``）は
    zero-init の新規 module ゆえ ``phase`` で一括し独立 ``film_lr`` 群にする（base 検出器に ``phase`` を
    含む param は無いので film/ca どちらでも安全）。トレーナーが ``requires_grad=False`` で凍結した層は
    自動的に除外される（film-only 学習に対応）。
    """
    linear_keywords = ("reference_points", "sampling_offsets")
    norm_bias_keywords = ("norm", "bias")
    backbone, backbone_norm = [], []
    linear_projection, linear_projection_norm = [], []
    other, other_norm = [], []
    phase_params = []
    for name, parameters in model.named_parameters():
        if not parameters.requires_grad:
            continue
        if match_name_keywords(name, "phase"):
            phase_params.append(parameters)
        elif (
            match_name_keywords(name, "backbone")
            and not match_name_keywords(name, linear_keywords)
            and match_name_keywords(name, norm_bias_keywords)
        ):
            backbone_norm.append(parameters)
        elif (
            match_name_keywords(name, "backbone")
            and not match_name_keywords(name, linear_keywords)
            and not match_name_keywords(name, norm_bias_keywords)
        ):
            backbone.append(parameters)
        elif (
            not match_name_keywords(name, "backbone")
            and match_name_keywords(name, linear_keywords)
            and match_name_keywords(name, norm_bias_keywords)
        ):
            linear_projection_norm.append(parameters)
        elif (
            not match_name_keywords(name, "backbone")
            and match_name_keywords(name, linear_keywords)
            and not match_name_keywords(name, norm_bias_keywords)
        ):
            linear_projection.append(parameters)
        elif match_name_keywords(name, norm_bias_keywords):
            other_norm.append(parameters)
        else:
            other.append(parameters)

    groups = [
        {"params": backbone, "lr": lr * 0.1},
        {"params": backbone_norm, "lr": lr * 0.1, "weight_decay": 0},
        {"params": linear_projection, "lr": lr * 0.1},
        {"params": linear_projection_norm, "lr": lr * 0.1, "weight_decay": 0},
        {"params": other_norm, "weight_decay": 0},
        {"params": phase_params, "lr": film_lr},
    ]
    if other:  # film-only 時は空になり得る
        groups.insert(0, {"params": other})
    return groups
